package br.coim.jcaguiar.provaathenas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProvaAthenasApplicationTests {

	@Test
	void contextLoads() {
	}

}
